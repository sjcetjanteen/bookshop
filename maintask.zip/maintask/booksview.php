<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>display</title>
    <style>
body{
    display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 20px;
            justify-items: center;
            padding: 20px;
            background-color: bisque;
}
.card {
    width: 200px;
    border: 1px solid #ddd;
    border-radius: 8px;
    background-color:lightseagreen;
    margin: 20px;
    padding: 20px;
  
}




.card-body {
    text-align: center;
}

.card-title {
    font-size: 1.5em;
    margin: 10px 0;
}

.card-author {
    font-size: 1.2em;
    color: black;
    margin-bottom: 10px;
}

.card-description {
    font-size: 1em;
    color: #555;
    margin: 10px 0;
}

.card-price,
.card-quantity {
    font-size: 1.1em;
    color: #333;
    margin: 10px 0;
}

.card-action button {
    padding: 10px 20px;
    background-color: #007bff;
    color: white;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    font-size: 1em;
}

.card-action button:hover {
    background-color: #0056b3;
}


    </style>
</head>

<body>

</body>

</html>
<?php

require_once './database.php';

$sql_show = "SELECT * FROM books";

$result = $conn->query($sql_show);

while ($row = $result->fetch_assoc()) {
   

?>

<div class="card">
    <div class="card-body">
       <?php
       if($row['quantity']>0){
        ?>
        <h3 class="card-title"><?= $row['title'] ?></h3>
        
       
        <h5 class="card-author"><?= $row['author'] ?></h5>

      
        <p class="card-description"><?= $row['description'] ?></p>

    
        <p class="card-price"><strong>Price:</strong> <?= $row['price'] ?></p>

      
        <p class="card-quantity"><strong>Quantity:</strong> <?= $row['quantity'] ?></p>

       
        <div class="card-action">
            <a href="buy.php?id=<?= $row['id'] ?>" class="buy-button">
                <button type="button">Buy</button>
            </a>
        </div>
       <?php }
       else{
       ?>
        <h3 class="card-title"><?= $row['title'] ?></h3>
        
       
        <h5 class="card-author"><?= $row['author'] ?></h5>

      
        <p class="card-description"><?= $row['description'] ?></p>

    
        <p class="card-price"><strong>Price:</strong> <?= $row['price'] ?></p>

      
        <p class="card-quantity"><strong><h4 style="color:red">out of stock<h4></strong> <?= $row['quantity'] ?></p>

        <?php
        
       } ?>
    </div>
</div>


   
<?php
    
}


?>

<a href="./welcome.php">back to home</a>