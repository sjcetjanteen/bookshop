<?php
session_start();
require_once './database.php';

if(isset($_SESSION['bolt'])){
    session_unset();
    session_destroy();

    header("location:login.php");
}else{
    $_SESSION['email'];
    session_unset();
    session_destroy();
    header("location:login.php");


}