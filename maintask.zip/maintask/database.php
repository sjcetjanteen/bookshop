<?php

$localhost="localhost";
$username="root";
$password="";
$database="book";

$conn=new mysqli($localhost,$username,$password,$database);