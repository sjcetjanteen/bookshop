<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Book</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            /* background-image: url(./book.jpg); */
            background-color: #555;
            background-size: cover;
            
            background-position: center;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }

        
        form {
            padding: 40px;
            border-radius: 10px;
            width: 400px;
            text-align: center;
        }

       
        #main {
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
        }

        
        h2 {
            color: #fff;
            font-size: 2rem;
            margin-bottom: 20px;
            font-weight: 600;
            font-family: cursive;
        }

        
        .inp {
            margin-bottom: 15px;
            width: 100%;
        }

        input {
            width: 100%;
            padding: 10px;
            margin: 5px 0;
            border-radius: 5px;
            border: 1px solid #ccc;
            font-size: 1rem;
            background-color: #fff;
        }

        

        
        label {
            color: #fff;
            font-size: 1.1rem;
            margin-bottom: 5px;
            display: block;
            font-family: cursive;

        }

        
        button {
            background-color: #4CAF50;
            color: #fff;
            padding: 12px 20px;
            border: none;
            border-radius: 5px;
            font-size: 1.1rem;
            cursor: pointer;
        }

        button:hover {
            background-color: green;
        }

       
        a {
            font-size: 1.2rem;
            color: beige;
            text-decoration: none;
            margin-top: 20px;
            display: inline-block;
            padding: 8px 20px;
            border-radius: 5px;
            background-color: #333;
            transition: background-color 0.3s ease;
        }

        a:hover {
            background-color: #555;
        }
    </style>
</head>

<body>

    <form action="./addbooks.php" method="post">
        <h2>Add Books</h2>
        <div id="main">
            <div class="inp">
                <label for="title">Book Title</label>
                <input type="text" name="title" id="title" required>
            </div>
            <div class="inp">
                <label for="author">Author</label>
                <input type="text" name="author" id="author" required>
            </div>
            <div class="inp">
                <label for="description">Description</label>
                <input type="text" name="description" id="description" required>
            </div>
            <div class="inp">
                <label for="price">Price</label>
                <input type="number" name="price" id="price" required>
            </div>
            <div class="inp">
                <label for="quantity">Quantity</label>
                <input type="number" name="quantity" id="quantity" required>
            </div>
            <button type="submit">Submit</button>
        </div>
    </form>

    <a href="./admin_view.php">View Books</a>

</body>

</html>
