<?php

require_once './database.php';


$id=$_POST['id'];
$name=$_POST['name'];
$quantity=$_POST['quantity'];



$sql_insert="INSERT INTO order(name,quantity)VALUES('$name','$email')";

if($conn->query($sql_insert)==true){
   
    
    
}
else{
    echo "connection error";
}