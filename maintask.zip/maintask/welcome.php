<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<style>
   *{
    padding: 0;
    margin: 0;
   }
   #nav {
        background-color: grey;
        height: 50px;
        display: flex;
        flex-direction: row;
        justify-content:space-between;
        font-size: 20px;
        align-items: center;
        padding: 3px;

        


    }
    h1{
        background-color: beige;
    }
    body{
        background-image: url(./book.jpg);
    }

    a:hover{
        color: black;
    }
    a{
        font-size: 25px;
        text-decoration: none;
    }
</style>

<body>

    <nav>
        <div id="nav">
           
                <div>
                    <a href="">Home</a>
                </div>
                <div>
                    <a href="./userorders.php">Order list</a>
                </div>
                
                <div><a href="./booksview.php"> Books</a></div>
                <div><a href="./logout.php">Logout</a></div>

           
        </div>
    </nav>
<?php
session_start();
require_once './database.php';
?>
<h1>welcome
<?php
//  echo $_SESSION['bolt'];

 if($_SESSION['bolt']==""){



   ?>
   <script>
    alert("please login to book");
    window.location.href="login.php";
   </script>

   <?php
 }
   ?>
   </h1>
</body>

</html>