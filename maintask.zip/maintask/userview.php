<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        table {
            background-color: paleturquoise;
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            padding: 10px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
        a{
            padding: 4px;
        }
    </style>
</head>
<body>
    <h2>Users List</h2>

    <?php
    require_once './database.php';

    $sql_user = "SELECT * FROM user";
    $result = $conn->query($sql_user);

    echo "<table border='1'>";
    echo "<thead>";
    echo "<tr>";
    echo "<th>Name</th>";
    echo "<th>Email</th>";
    echo "<th>Password</th>";
    echo "<th>Address</th>";
    echo "<th>Actions</th>"; 
    echo "</tr>";
    echo "</thead>";
    echo "<tbody>";

   
    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . $row['name'] . "</td>";
        echo "<td>" . $row['email'] . "</td>";
        echo "<td>" . $row['password'] . "</td>";
        echo "<td>" . $row['address'] . "</td>";
        echo "<td> 
               
                <a href='deleteuser.php?id=" . $row['id'] . "' onclick='return warning()'>Remove</a>
              </td>";
        echo "</tr>";
    }

    echo "</tbody>";
    echo "</table>";
    ?>

    <br>
    <a href="./admin_view.php">Go back</a>
</body>
<script>
    function warning(){
        return confirm( "are you sure to remove this user ");
    }
</script>
</html>
