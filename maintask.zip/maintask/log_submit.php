
<?php

session_start();
require_once './database.php';
 
if (isset($_POST)) {
    $email = $_POST['email'];
    $password = $_POST['password'];
    
    

    $sql_select = "SELECT * from user where email='$email'";
    $result = mysqli_query($conn, $sql_select);
    $s = mysqli_fetch_assoc($result);
 
    $sql_login = "SELECT * FROM user WHERE (email='$email') AND password='$password'";
    $result = $conn->query($sql_login);


     if($email==="admin@gmail.com" && $password==='admin'){
        $_SESSION['admin']=$email;
        // var_dump($_SESSION);
        // die;
        
        header("location:adminhome.php");

    }
 
    else if ($s['email'] === $email && $s['password'] === $password) {
    
        $_SESSION['id'] = $s['id'];
        $_SESSION['bolt'] = $s['name'];
        $_SESSION['dolly'] = $s['email'];


        header("Location: welcome.php");
        exit;
    } 
    
    else {
        echo "log in not succesful";
    }
}
?>
<br><br>
<a href="login.php">go back</a>