<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        body{
            display: flex;
            flex-direction: column;
           background-color: bisque;
            margin-top: 100px;
        }
        table{
            background-color: lightgrey;
            margin-top: 30px;
            font-family: monospace;
            font-size: 20px;
        }
        #head{
            margin-top: 10px;
        }
       
    </style>
</head>
<body>
    <div id="head">
<h1>My Orders</h1>
<a href="./welcome.php">back to home</a>

    </div>
</body>
</html>

<?php
session_start();
require_once './database.php';
$email=$_SESSION['dolly'];
$id=$_SESSION['id'];
// var_dump($_SESSION);
// die;

$sql_order="SELECT `order`.id AS order_id,books.title,`order`.`quantity`,`user`.`name`,`user`.`email`,`order`.id FROM `books` INNER JOIN `order` ON `order`.`bookid`=books.id INNER JOIN `user` ON user.id =`order`.userid WHERE user.id='$id' ";

$res = $conn->query($sql_order);
echo "<table border=2>";
echo "<th>order_id</th><th>book Title</th><th>quantity</th><th>name</th><th>email</th><th>edit</th>";
while($row=$res->fetch_assoc()){
echo "<tr>";
    echo "<td>" . $row['order_id'] . "</td>";
    echo "<td>" . $row['title'] . "</td>";
    echo "<td>" . $row['quantity'] . "</td>";
    echo "<td>" . $row['name'] . "</td>";
    echo "<td>" . $row['email'] . "</td>";
    echo '<td><a href=./removeorder.php?id='.$row['id'].' onclick="return rmv() " >Remove</a></td>';
    

   
echo "<tr>";

}
echo "</table>";

?>
<script>
    function rmv(){
        return confirm("do you want to remove this order");
    }
</script>





