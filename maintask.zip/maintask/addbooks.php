<?php

require_once './database.php';

$title = $_POST['title'];
$author = $_POST['author'];
$description = $_POST['description'];
$price=$_POST['price'];
$quantity=$_POST['quantity'];


if ($title != "" && $author != "" && $description !="" && $price !="" && $quantity !="") {

        

    $query = "INSERT INTO books (title,author,description,price,quantity) VALUES ('$title','$author','$description','$price','$quantity')";

    $result = mysqli_query($conn, $query);
    if($result){
        // echo "inserted book";
header("location:admin_view.php");
        
    }else{
        echo "failed";
    }
    
}

?>




