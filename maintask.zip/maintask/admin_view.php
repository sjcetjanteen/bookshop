<?php
session_start();
require_once './database.php';
if(empty($_SESSION['admin'])){
?>
    <script>
        alert("please log in");
        window.location.href='login.php';
    </script>

    <?php
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>display</title>
    <style>
        body {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 20px;
            justify-items: center;
            padding: 20px;
            background-color: #777;
        }

        .card {
            padding: 20px;
            width: 200px;
            border-radius: 8px;
            background-color: lightseagreen;
            margin: 20px;
            
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);



        }

        .card:hover {
            box-shadow: 0 8px 12px rgba(0, 0, 0, 0.15);
        }


        .card-body {
            text-align: center;
        }

        .card-title {
            font-size: 1.5em;
            margin: 10px 0;
        }

        .card-author {
            font-size: 1.2em;
            color: #777;
            margin-bottom: 10px;
        }

        .card-description {
            font-size: 1em;
            color: #555;
            margin: 10px 0;
        }

        .card-price,
        .card-quantity {
            font-size: 1.1em;
            color: #333;
            margin: 10px 0;
        }

        .card-action button {
            padding: 10px 20px;
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 1em;
        }

        .card-action button:hover {
            background-color: #0056b3;
        }

        h2 {
            color: #0056b3;
        }

        #btn {
            display: flex;
            justify-content: space-around;
        }

        #btn #del {
            background-color: red;
        }
        a{
            font-size: 20px;
        }
    </style>
</head>

<body>
    
</body>
<script>
    function deletebook(){
        return confirm("are you want to delete")
    }
</script>

</html>
<?php

require_once './database.php';

$sql_show = "SELECT * FROM books";

$result = $conn->query($sql_show);

while ($row = $result->fetch_assoc()) {


?>

    <div class="card">
        <div class="card-body">

            <h3 class="card-title"><?= $row['title'] ?></h3>


            <h5 class="card-author"><?= $row['author'] ?></h5>


            <p class="card-description"><?= $row['description'] ?></p>


            <p class="card-price"><strong>Price:</strong> <?= $row['price'] ?></p>


            <p class="card-quantity"><strong>Quantity:</strong> <?= $row['quantity'] ?></p>


            <div id="btn">
                <div class="card-action">
                    <a href="edit.php?id=<?= $row['id'] ?>" class="buy-button">
                        <button type="button">Edit</button>
                    </a>
                </div>
                <div class="card-action">
                    <a href="deletebook.php?id=<?= $row['id'] ?> ' " class="buy-button">
                        <button type="button" id="del" onclick='return deletebook()'>Delete</button>
                    </a>
                </div>
            </div>
        </div>
    </div>


<?php

}


?>

<br>
<a href="./adminhome.php">go back to home</a>