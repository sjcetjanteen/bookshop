<?php
session_start();

require_once './database.php';


//select and purchase
if (isset($_GET)) {
    $id = $_GET['id'];
}
?>

<?php

if($_SESSION['bolt']=="")
{
    ?>

<script>
    alert("please login to book");
    window.location.href="login.php";
   </script>

   <?php
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<style>
    body{
        background-color: bisque;
    }
    #box {
        background-color: grey;
        height: 250px;
        width: 250px;
        margin: 200px;
        border-radius: 10px;
        display: flex;
        text-align: center;



    }

    h4 {
        width: 100%;
    }

    h2 {
        text-align: center;
        font-family: Arial, Helvetica, sans-serif;
        padding: 10px;
    }

    button {
        padding: 10px 20px;
        background-color: #0056b3;

        color: white;
        border: none;
        border-radius: 5px;
        cursor: pointer;
        font-size: 1em;
    }

    button:hover {
        background-color: green;

    }
    #error{
        color: red;
        font-size: small;
        margin-bottom: 4px;
    }
    
</style>

<body>
    <div id="box">
        <?php



        $sql_view = "SELECT * FROM books WHERE id= " . $id;
        $res = mysqli_query($conn, $sql_view);

        if ($res = mysqli_fetch_assoc($res)) {
        ?>

            <form action="buy_qty_update.php" method="post" onsubmit="return count(event)">

                <div>
                    <h2><?= $res['title'] ?></h2>
                </div>
                <div>
                    <h4></h4>
                </div>
                <hr>
                <div>
                    <h5>available: <span id="quantity"><?= $res['quantity'] ?></span></h5>
                </div>
                <div>
                    <h4>quantity
                        <input type="number" id="inp" name="inp">
                    </h4>
                <span class="error" id="error"></span>

                </div>
                <div>
                    <button type="submit">confirm order</button>
                </div>
                <input type="hidden" name="id" id="id" value="<?= $res['id'] ?>">
                <input type="hidden" name="quan" id="quan" value="<?= $res['quantity'] ?>">
                <input type="hidden" name="name" id="name" value="<?= $res['title'] ?>">
            </form>


        <?php
        }
        ?>

    </div>
</body>
<script>
    function count(event) {
        
        var input = document.getElementById("inp").value;
        var quantity = document.getElementById("quantity").innerHTML;

        var inp = parseInt(input);
        var qua = parseInt(quantity);
        if(inp > qua){
            
            event.preventDefault()
            
            document.getElementById("error").innerHTML="quantity more than available";
            
            return false;
        }
        return true;
    }
</script>

</html>