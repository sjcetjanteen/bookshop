<?php

require_once './database.php';

$id=$_GET['id']??null;
if($id==null){
    die("invalid request");
}

$sql_delete = "DELETE FROM user WHERE id=".$id;
if($result =$conn->query($sql_delete)){
    header("location:userview.php");
}