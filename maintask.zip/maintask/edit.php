<?php
require_once './database.php';


$id=$_GET['id']??null;
if($id==null){
    die("invalid request");    
}

$sql_select = "SELECT * FROM books WHERE id=".$id;
$result=$conn->query($sql_select);
$row =$result->fetch_assoc();

?>

<form action="./updatebook.php" method="post">
<h2>Edit books</h2>
        <div id="main">

        <input type="hidden" name="id" value=" <?php echo $row['id'];?>">

            <div class="inp">
                <label for="">booktitle</label>
                <input type="text" name="title" value="<?php echo $row['title'] ?>" >
            </div>
            <div class="inp">
                <label for="">Author</label>
                <input type="text" name="author" value="<?php echo $row['author'] ?>" >
            </div>

            <div class="inp">
                <label for="">description</label>
                <input type="text" name="description" value="<?php echo $row['description'] ?>" >
            </div>
            <div class="inp">
                <label for="">price</label>
                <input type="number" name="price" value="<?php echo $row['price'] ?>" >
            </div>
            <div>


                <label for="">quantity</label>

                <input type="number" name="quantity" value="<?php echo $row['quantity'] ?>" >
            </div>
<div>
    <button type="submit">submit</button>
</div>

        </div>

    </form>
 
