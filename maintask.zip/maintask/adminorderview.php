<?php 
session_start();
require_once './database.php';
if(empty($_SESSION['admin'])){
?>
    <script>
        alert("please log in");
        window.location.href='login.php';
    </script>

    <?php
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        body{
            display: flex;
            flex-direction: column;
            background-color: beige;
        }
        table{
            background-color: bisque;
            font-family: monospace;
            font-size: 15px;
            padding: 10px;
            text-align: center;
            align-items: center;
        }
        h2{
            text-align: center;
        }
    </style>
</head>
<body>
    <div id="headd">
<h2>Users Orders</h2>
    </div>
    <a href="./adminhome.php">go to home</a>
</body>
</html>

<?php

require_once './database.php';



$sql_order="SELECT `order`.`id`AS order_id, books.title,books.quantity,user.name,user.email FROM `books` INNER JOIN `order` ON `order`.`bookid`=books.id INNER JOIN `user` ON user.id =`order`.userid;";
// var_dump($_POST);
// die;
$res = $conn->query($sql_order);
echo "<table border=1>";
echo "<th>order_id</th><th>booking details</th><th>quantity</th><th>ordered by</th><th>email</th>";
while($row=$res->fetch_assoc()){
echo "<tr>";
    echo "<td>" . $row['order_id'] . "</td>";
    echo "<td>" . $row['title'] . "</td>";
    echo "<td>" . $row['quantity'] . "</td>";
    echo "<td>" . $row['name'] . "</td>";
    echo "<td>" . $row['email'] . "</td>";
    
echo "<tr>";

}
echo "</table>";



