<?php
session_start();

require_once './database.php';


//using session variable storing the logged user
$user = $_SESSION['bolt'];
$useremail=$_SESSION['dolly'];
$input = $_POST['inp'];
$quantity = $_POST['quan'];
$id = $_POST['id'];
$user_id = $_SESSION['id'];
// var_dump($_POST);
// die;
$name = $_POST['name'];
// $quantity=$_POST['quantity'];


$count = $quantity - $input;
$sql_update = "UPDATE books SET quantity=$count WHERE id=" . $id;
// var_dump($sql_update);
// die;
$result = mysqli_query($conn, $sql_update);
if ($result) {


    $sql_insert = "INSERT INTO `order`(`bookid`, `quantity`,`userid`) VALUES ('$id','$input','$user_id')";


    if ($conn->query($sql_insert)) {
        header("location:booksview.php");
    }
} else {
    echo "something went wrong";
}


// if($conn->query($sql_insert)==true){
       
// }
// else{
//     echo "connection error";
// }
