<?php
session_start();
require_once './database.php';

$name = $_POST['name'];
$email = $_POST['email'];
$password = $_POST['password'];
$phone = $_POST['phone'];
$address = $_POST['address'];

//email check

$email_check = "SELECT * FROM user WHERE email='$email' ";
$res = $conn->query($email_check);
if ($res->num_rows > 0) {
    echo "email already exists";
} else {


    //user insert
    $sql_insert = "INSERT INTO user(name,email,password,phone,address)VALUES('$name','$email','$password','$phone','$address')";

    if ($conn->query($sql_insert) == true) {
        $_SESSION['bolt'] = $name;
        header("location:login.php");
    } else {
        echo "connection error";
    }
}

?>
<!-- <br>
<a href="./login.php">log in here</a> -->