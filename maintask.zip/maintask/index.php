<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="./style.css">
</head>
<style>
    body{
        display: flex;
        justify-content: center;
        height: 80vh;
        align-items: center;
        background-image: url(./book.jpg);
    }
    input,textarea{
        padding: 10px;
        border-radius: 8px;
    }
    form{
        background-color: grey;
        padding: 50px;
        border-radius: 8px;
        margin-top: 40px;

    }
    
    button{
        background-color: green;
        padding: 5px;
        margin-left: 100px;
        width: 100px;
        border-radius: 5px;

    }
    button:hover{
        background-color: lightgreen;
       
    }
    .main{
        display: flex;
        flex-direction: column;
        
    }
    label,input,textarea{
width: 100%;
    }
    a:hover{
        color: black;
    }
</style>

<body>
    <form action="./insert.php" method="post" onsubmit="return validate()">
        <div class="main">
            <h3>register Book Purchasing</h3>
            <div>
                <label for="">name</label>
                <input type="text" id="name" name="name">
            </div>
            <span class="error" id="nameerror"></span>
            <div>
                <label for="">Email</label>
                <input type="email" id="email" name="email">
            </div>
            <span class="error" id="emailerror"></span>

            <div>
                <label for="">Password</label>
                <input type="password" id="pwd" name="password">
            </div>
            <span class="error" id="pwderror"></span>

            <div>
                <label for="">Phone number</label>
                <input type="number" id="phone" name="phone">
            </div>
            <span class="error" id="phoneerror"></span>

            <div>
                <label for="">Delivery address</label>
                <textarea name="address" id="address" rows="3"></textarea>
            </div>
            <span class="error" id="deliveryerror"></span>
<br>
            <div>
                <button type="submit">register</button>
            </div>
        </div>
        <a href="./login.php">already user</a>
    </form>
</body>

<script>
    function validate(){

        document.getElementById("nameerror").innerHTML="";
        document.getElementById("emailerror").innerHTML="";
        document.getElementById("pwderror").innerHTML="";
        document.getElementById("phoneerror").innerHTML="";
        document.getElementById("deliveryerror").innerHTML="";

        const name=document.getElementById("name").value;
        const email=document.getElementById("email").value;
        const password=document.getElementById("pwd").value;
        const phone=document.getElementById("phone").value;
        const address=document.getElementById("address").value;

        if(name===""){
            document.getElementById("nameerror").innerHTML="required name";
            return false;
        }
        if(email===""){
            document.getElementById("emailerror").innerHTML="email required ";
            return false;  
        }
        if(password===""){
            document.getElementById("pwderror").innerHTML="required ";
            return false;

        }
        else if(password.length<4){
            document.getElementById("pwderror").innerHTML="minimum 4 characters ";
            return false;

        }
        if(phone===""){
            document.getElementById("phoneerror").innerHTML="required ";
            return false;

        }
        else if(phone.length<10){
            document.getElementById("phoneerror").innerHTML=" phone muat be 10 digits ";
            return false;
        }
        if(address===""){
            document.getElementById("deliveryerror").innerHTML="required ";
            return false;

        }

        return true;
    }
</script>

</html>