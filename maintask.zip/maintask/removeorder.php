<?php

require_once './database.php';

$id = $_GET['id'];

$sql1="SELECT `order`.`id`,books.id AS bookid,`order`.`quantity` FROM `books` INNER JOIN `order` on books.id = `order`.bookid INNER JOIN `user` on `user`.`id`=`order`.`userid`WHERE `order`.`id`='$id'";

$res=$conn->query($sql1);


$result = mysqli_fetch_assoc($res);


$user = $result['bookid'];
$quantity = $result['quantity'];





$sql_remove = "DELETE FROM `order` WHERE id = " . $id;


if ($conn->query($sql_remove)) {

    $update_qty = "UPDATE books SET quantity = quantity + $quantity  WHERE id ='$user'";
    if ($conn->query($update_qty) == true) {
        header("location:userorders.php");
    }
} else {
    echo "something went wrong";
    header("location:userorders.php");
}
