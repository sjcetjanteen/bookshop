<?php

require_once './database.php';

$id=$_POST['id'];
$title=$_POST['title'];
$author=$_POST['author'];
$description=$_POST['description'];
$price=$_POST['price'];
$quantity=$_POST['quantity'];

$sql_update="UPDATE books SET title='$title' , author='$author' , description='$description' ,price='$price',quantity='$quantity' WHERE id=" . $id;

if ($conn->query($sql_update) === true) {
    header("location:admin_view.php");
} else {
    echo "error";
}