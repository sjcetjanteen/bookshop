<?php
session_start();
require_once './database.php';
if(empty($_SESSION['admin'])){
?>
    <script>
        alert("please log in");
        window.location.href='login.php';
    </script>

    <?php
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<style>
    *{
        padding: 0;
        margin: 0;
    }
    #nav {
        background-color: grey;
        height: 50px;
        display: flex;
        flex-direction: row;
        justify-content:space-between;
        font-size: 20px;
        align-items: center;
        padding: 3px;

        


    }
    h1{
        background-color: beige;
    }
    body{
        background-image: url(./book.jpg);
    }

    a:hover{
        color: black;
    }
    h3{
        background-color: white;
    }
    a{
        font-size: 18px;
        text-decoration: none;
        font-family: 'Lucida Sans', 'Lucida Sans Regular', 'Lucida Grande', 'Lucida Sans Unicode', Geneva, Verdana, sans-serif;
    }
</style>

<body>

    <nav>
        <div id="nav">
           
                <div>
                    <a href="">home</a>
                </div>
                <div>
                    <a href="./admin_view.php">edit</a>
                </div>
                <div>
                    <a href="./adminorderview.php">user orders</a>
                </div>
                <div><a href="./userview.php">view users</a></div>

                
                <div><a href="./books.php">add books</a></div>
                <div><a href="./logout.php">logout</a></div>
                

           
        </div>
    </nav>


 
   <h3>Admin Page</h3>
</body>

</html>